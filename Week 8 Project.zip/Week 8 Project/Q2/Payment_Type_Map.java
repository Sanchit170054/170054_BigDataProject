
/*
 *	Driver.java
 *
 *  Created on: October 01, 2019
 *      Author: Sanchit
 */

package Question2;


import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

public class Payment_Type_Map extends MapReduceBase implements Mapper <LongWritable, Text, Text, IntWritable> {
	private final static IntWritable intwritable = new IntWritable(1);

	public void map(LongWritable key, Text value, OutputCollector <Text, IntWritable> output, Reporter reporter) throws IOException {

		String fetchedValue = value.toString(); //convert the coming value into string
		String[] split_value = fetchedValue.split(","); //split the value from comma
		output.collect(new Text(split_value[3]), intwritable); 
	}
}