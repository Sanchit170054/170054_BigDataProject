

/*
 *	Payment_Type_Reduce.java
 *
 *  Created on: October 01, 2019
 *      Author: Sanchit
 */

package Question2;


import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

public class Payment_Type_Reduce extends MapReduceBase implements Reducer<Text, IntWritable, Text, IntWritable> {

	public void reduce(Text key, Iterator<IntWritable> values, OutputCollector<Text,IntWritable> output, Reporter reporter) throws IOException {
		Text key = key;
		int count_value = 0;
		while (values.hasNext()) { //if there is value
			IntWritable new_value = (IntWritable) values.next(); //replace the value wiht the actual coming value
			count_value += value.get(); // update the count_value
			
		}
		output.collect(key, new IntWritable(count_value));
	}
}