
/*
 * Product_sold_Reduce.java
 *
 *  Created on: October 01, 2019
 *      Author: Sanchit
 */

package Question1;

import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

public class Product_sold_Reduce extends MapReduceBase implements Reducer<Text, IntWritable, Text, IntWritable> {
	
	public void reduce(Text key, Iterator<IntWritable> values, OutputCollector<Text,IntWritable> output, Reporter reporter) throws IOException {
		Text key = key;
		int product_number = 0;
		while (values.hasNext()) { //if there is a value
			IntWritable value = (IntWritable) values.next();  // replace this with the actual value
			product_number += value.get(); //add the fetched value into number			
		}
		output.collect(key, new IntWritable(product_number));
	}
}