/*
 *	temp_predict_Map.java
 *
 *  Created on: October 01, 2019
 *      Author: Sanchit
 */

package Question4;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class temp_predict_Map extends Mapper<LongWritable, Text, Text, Text> {
public static final int MISSING = 9999;

public void map(LongWritable arg0, Text Value, Context context) throws IOException, InterruptedException {
	
			String recorded_line = Value.toString(); //get the line 
			
			if (!(line.length() == 0)) { //if there is line
				
				String get_date = recorded_line.substring(6, 14); //fetch the date

				float maximum_temp = Float.parseFloat(recorded_line.substring(39, 45).trim()); //get the maximum temprature
				
				float minimum_temp = Float.parseFloat(recorded_line.substring(47, 53).trim()); //get the minimum temprature


				if ( maximum_temp != MISSING && minimum_temp != MISSING) { 
					// Declared it as Hot day and cold day
					context.write(new Text("|Time/Date: " + get_date+ " | "),
							new Text(String.valueOf(" Maximum Temperature: "+ maximum_temp+ 
							"\t|  Minimum Temperature: "+ minimum_temp+ "\t|")));
				}	
               
			}
		}
}
	