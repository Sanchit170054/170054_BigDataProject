
/*
 *	temprature_find_Mappper.java
 *
 *  Created on: October 02, 2019
 *      Author: Sanchit
 */

package Question2;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class temprature_find_Mappper extends Mapper<LongWritable, Text, Text, Text> {
	
public static final int MISSING = 9999;

public void map(LongWritable arg0, Text Value, Context context)
				throws IOException, InterruptedException {
		
			String recorded_line = Value.toString(); //convert the coming value into string and store it    
            
			if (!(recorded_line.length() == 0)) { //if the lenght of line is not equal to 0
			
				String recorded_date = line.substring(6, 14); //fetch the date
				
				float maximum_temp = Float.parseFloat(recorded_line.substring(39, 45).trim()); //get the maximum temperature
				
				float minimum_temp = Float.parseFloat(recorded_line.substring(47, 53).trim()); //get the minimum temperature

				if ( maximum_temp != MISSING && maximum_temp > 35.0) { //if temperature is greater
					// Declare it as Hot day
					context.write(new Text("Hot Day " + recorded_date),new Text(String.valueOf(maximum_temp)));
				}
				
				if (temp_Min != MISSING && temp_Min < 10) { //if temperature is less
					// Declare it as Cold day
					context.write(new Text("Cold Day " + recorded_date),new Text(String.valueOf(minimum_temp)));
				}
               
			}
		}
}
	