
import matplotlib.pyplot as plt
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import association_rules, apriori

df = pd.read_csv('BreadBasket_DMS.csv')
transaction_list = []
for i in df['Transaction'].unique():
    tlist = list(set(df[df['Transaction'] == i]['Item']))
    if len(tlist) > 0:
        transaction_list.append(tlist)

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

getCountList = []
te = TransactionEncoder()
te_ary = te.fit(transaction_list).transform(transaction_list)
df2 = pd.DataFrame(te_ary, columns=te.columns_)
# frequent_itemsets = apriori(df2, min_support=0.01, use_colnames=True)
#
# # Confidence Level = 90%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.09)
# getCountList.append(len(rules))
# print("Rules generated at 90% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 80%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.08)
# getCountList.append(len(rules))
# print("Rules generated at 80% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 70%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.07)
# getCountList.append(len(rules))
# print("Rules generated at 70% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 60%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.06)
# getCountList.append(len(rules))
# print("Rules generated at 60% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 50%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.05)
# getCountList.append(len(rules))
# print("Rules generated at 50% Confidence:  " +str(len(rules)))
#
# # Confidence Level = 40%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.04)
# getCountList.append(len(rules))
# print("Rules generated at 40% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 30%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.03)
# getCountList.append(len(rules))
# print("Rules generated at 30% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 20%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.02)
# getCountList.append(len(rules))
# print("Rules generated at 20% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 10%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.01)
# getCountList.append(len(rules))
# print("Rules generated at 10% Confidence:  " + str(len(rules)))
#
# frequent_itemsets = apriori(df2, min_support=0.005, use_colnames=True)
#
# # Confidence Level = 90%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.09)
# getCountList.append(len(rules))
# print("Rules generated at 90% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 80%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.08)
# getCountList.append(len(rules))
# print("Rules generated at 80% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 70%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.07)
# getCountList.append(len(rules))
# print("Rules generated at 70% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 60%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.06)
# getCountList.append(len(rules))
# print("Rules generated at 60% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 50%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.05)
# getCountList.append(len(rules))
# print("Rules generated at 50% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 40%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.04)
# getCountList.append(len(rules))
# print("Rules generated at 40% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 30%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.03)
# getCountList.append(len(rules))
# print("Rules generated at 30% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 20%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.02)
# getCountList.append(len(rules))
# print("Rules generated at 20% Confidence:  " + str(len(rules)))
#
# # Confidence Level = 10%
# rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.01)
# getCountList.append(len(rules))
# print("Rules generated at 10% Confidence:  " + str(len(rules)))


frequent_itemsets = apriori(df2, min_support=0.0005, use_colnames=True)

# Confidence Level = 90%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.09)
getCountList.append(len(rules))

print("Rules generated at 90% Confidence:  " + str(len(rules)))

# Confidence Level = 80%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.08)
getCountList.append(len(rules))
print("Rules generated at 80% Confidence:  " + str(len(rules)))

# Confidence Level = 70%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.07)
getCountList.append(len(rules))
print("Rules generated at 70% Confidence:  " + str(len(rules)))

# Confidence Level = 60%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.06)
getCountList.append(len(rules))
print("Rules generated at 60% Confidence:  " + str(len(rules)))

# Confidence Level = 50%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.05)
getCountList.append(len(rules))
print("Rules generated at 50% Confidence:  " + str(len(rules)))

# Confidence Level = 40%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.04)
getCountList.append(len(rules))
print("Rules generated at 40% Confidence:  " + str(len(rules)))

# Confidence Level = 30%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.03)
getCountList.append(len(rules))
print("Rules generated at 30% Confidence:  " + str(len(rules)))

# Confidence Level = 20%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.02)
getCountList.append(len(rules))
print("Rules generated at 20% Confidence:  " + str(len(rules)))

# Confidence Level = 10%
rules = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.01)
getCountList.append(len(rules))
print("Rules generated at 10% Confidence:  " + str(len(rules)))

height = [10, 24, 36, 40, 5]
tick_label = ['90%', '80%', '70%', '60%', '50%', '40%', '30%', '20%', '10%']
fig = plt.figure(figsize=(10, 5))

plt.bar(tick_label, getCountList, color='blue', width=0.4)
plt.xlabel('Confidence Level')
plt.ylabel('Generated Rules')
plt.title('With Support Level 0.5%')

plt.show()
